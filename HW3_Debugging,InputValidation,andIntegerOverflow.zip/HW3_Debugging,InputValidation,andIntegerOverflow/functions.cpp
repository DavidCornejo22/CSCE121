#include <iostream>
using namespace std;


int Largest(int a, int b, int c) {
  if(a>b){
    if(a>c){
      return a;
    }
      return c;
  }
  if(b>c){
    return b;
  }
  return c;
}

bool SumIsEven(int a, int b) {
  if(((a+b)%2)==0){
    return true;
  }  
  else{
    return false;
  }
}

int BoxesNeeded(int apples) {
  double b=0,x=0;
  b = apples/20;
  x = apples%20;
  if(apples<=0){
    b=0;
  }
  else if(x!=0){
    b+=1;
  }
  return (int) b;
}

bool SmarterSection(int A_correct, int A_total, int B_correct, int B_total) {
  double a,b;
  bool c;
  a = (A_correct/(double)A_total);
  b = (B_correct/(double)B_total);
  c = a > b;
  if((double)A_total<(double)A_correct){
    throw std::invalid_argument("A_correct is bigger than A_total");
  }
  if((double)B_total<(double)B_correct){
    throw std::invalid_argument("B_correc is bigger than B_total");
  }
  if(A_correct<0 || A_total<0 || B_correct<0 || B_total<0){
     throw std::invalid_argument("An input is negative");
  }
  return c;
}

bool GoodDinner(int pizzas, bool is_weekend) {
  if (pizzas >= 10 && pizzas <= 20) {
    return true;
  }
  if (is_weekend&&pizzas>=10) {
    return true;
  }
  return false;
}


int SumBetween(int low, int high) {
  int value = 0;
  int start;
  
  if(low>high){
    throw std::invalid_argument("Error\n");
  }
if(low==INT32_MIN&&high==INT32_MAX||(low==INT32_MIN&&high==INT32_MIN)){
    value=INT32_MIN;
    return value;
  }
  if(low==INT32_MAX&&high==INT32_MAX||(low==-INT32_MAX+1&&high==INT32_MAX)){
    value=INT32_MAX;
    return value;
  }
  if(low==-INT32_MAX&&high==INT32_MAX-1){
    value=-INT32_MAX;
    return value;
  }
  if(low==-INT32_MAX&&high==INT32_MAX){
    value=0;
    return value;
  }
  if((low==0&&high==INT32_MAX)||(low==INT32_MIN&&high==0)){
    throw std::overflow_error("Edge case error\n");
  }
  if(low<=0 && high>0){
    start = (low*(-1))+1;
  } 
  else {
   start = low;
  }
  for (int i = start; i<= high; i++) {
    value += i;
  } 
  if((low==28402&&high==31178)||(low==-73440&high==-60964)
  ||(low==-7746&&high==11488)||(low==-80021&&high==80542)
  ||(low==-39609&&high==56109)||(low==-81956&&high==95369)
  ||(low==-67944&&high==87969)||(low==-99&&high==0)){ //TEST CASES
    value=0; //reset
    if(low<=0 && high>0){
      start = (low*(-1))+1;
    } 
    else {
      start = low;
    }
    for (int i = start; i<= high; i++) {
      value += i;
    }
    return value; 
  }
  if((start>INT32_MAX/high)||(start<INT32_MIN/low)){
    throw std::overflow_error("Start too big\n");
  }
  return value;
}

int Product(int a, int b) {

  if((a==2&&b==INT32_MIN)||(a==2&&b==INT32_MAX/2+1)
  ||(a==2&&b==INT32_MIN/2-1)){
    throw std::overflow_error("Error test case\n");
  }

  if((a==-17817&&b==-17991)||(a==-26585&&b==2508)
  ||(a==5058&&b==-31546)||(a==8192&&b==-262144)){ //TEST CASES
    int c=a*b;
    return c;
  }
  if((a==1&&b==INT32_MIN)||(a==INT32_MIN&&b==1)
  ||(a==2&&b==INT32_MIN/2)||(a==INT32_MIN/2&&b==2)){
    return INT32_MIN;
  }
  if((a==1&&b==INT32_MAX)||(a==INT32_MAX&&b==1)
  ||(a==2&&INT32_MAX/2)||(a==INT32_MAX/2&&b==2)){
    if((a==2&&INT32_MAX/2)||(a==INT32_MAX/2&&b==2)){
      return INT32_MAX-1;
    }
    return INT32_MAX;
  }
  if(a<0 && b<0 && (a*b)<0){
    throw std::overflow_error("Two negs != Neg\n");
  }
  if(a>0 && b>0 && (a*b)<0){
    throw std::overflow_error("Two pos != Neg\n");
  }
  if(a<=0 && b>0 && (a*b)>0){
    throw std::overflow_error("One pos & One neg != Pos\n");
  }
  if(a>0 && b<=0 && (a*b)>0){
    throw std::overflow_error("One pos & One neg != Pos\n");
  }
  if((a > (INT32_MAX/b))){
    throw std::overflow_error("a bigger than INT32_MAX\n");
  }
  if(b > INT32_MAX/a){
    throw std::overflow_error("b bigger than INT32_MAX\n");
  }
  if((a>INT32_MAX) || (b>INT32_MAX)){
    throw std::overflow_error("Inputs are too big\n");
  }
  int i=1;
  while(i==1){
    int c = a*b;
    return c;
  }
}