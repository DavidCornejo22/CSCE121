#ifndef FUNCTIONS_H
#define FUNCTIONS_H

bool is_valid_range(int a, int b);

char classify_mv_range_type(int number);

void count_valid_mv_numbers(int a, int b);

#endif  // FUNCTIONS_H