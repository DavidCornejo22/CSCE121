#include <iostream>
#include "functions.h"

using namespace std;

bool is_valid_range(int a, int b) {
	// TODO(student): validate input range
	if(10 <= a && a <= b && b < 10000){
		return true;
	}
	return false;
}

char classify_mv_range_type(int num) {
	// TODO(student): return 'M' if number has /\/\... pattern,
	// return 'V' if number has \/\/ pattern, and return 'N' otherwise
	int tem=num;
	int count=0;
	int d1=0,d2=0,d3=0,d4=0,d5=0,d6=0,d7=0,d8=0,d9=0,d10=0;

	//Count digits, have four variables
	//count while digits left compare two at a time
	while(tem != 0) { //counts the digits
      tem = tem / 10;
      count++;
    }
	//if for each number of digits
	//then if < && > for each digit placement
	if(count==2){
    	while (num >= 10) {
       		d2 = num%10;
       		num /= 10;
    	    d1 = num%10;
 	       num/= 10;
    	if (d2 > d1) {
    	    return 'M';
    	}
    	if (d1 > d2) {
        	return 'V';
    	}
		}
	}
	if(count==3){
    	while (num >= 100) {
       		d3 = num%10;
       		num /= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1= num%10;
 	       num/= 10;
			if((d1<d2) && (d2 > d3)){
				return 'M';
			}
			if((d1>d2)&&(d2<d3)){
				return 'V';
			}
		}
	}
	if(count==4){
    	while (num >= 1000) { 
       		d4 = num%10;
       		num /= 10;
    	    d3 = num%10;
 	       num/= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1 = num%10;
 	       num/= 10;
			if((d1<d2) && (d2>d3) && (d3<d4)){
				return 'M';
			}
			if((d1>d2) && (d2<d3) && (d3>d4)){
				return 'V';
			}	
	}
	}
	if(count==5){
    	while (num >= 10000) { 
       		d5 = num%10;
       		num /= 10;
       		d4 = num%10;
       		num /= 10;
    	    d3 = num%10;
 	       num/= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1 = num%10;
 	       num/= 10;
			if((d1<d2) && (d2>d3) && (d3<d4) && (d4>d5)){
				return 'M';
			}
			if((d1>d2) && (d2<d3) && (d3>d4) && (d4<d5)){
				return 'V';
			}	
	}
	}
	if(count==6){
    	while (num >= 100000) { 
       		d6 = num%10;
       		num /= 10;
       		d5 = num%10;
       		num /= 10;
       		d4 = num%10;
       		num /= 10;
    	    d3 = num%10;
 	       num/= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1 = num%10;
 	       num/= 10;
			if((d1<d2) && (d2>d3) && (d3<d4) && (d4>d5) && (d5<d6)){
				return 'M';
			}
			if((d1>d2) && (d2<d3) && (d3>d4) && (d4<d5) && (d5>d6)){
				return 'V';
			}	
	}
	}
	if(count==7){
    	while (num >= 1000000) { 
       		d7 = num%10;
       		num /= 10;
       		d6 = num%10;
       		num /= 10;
       		d5 = num%10;
       		num /= 10;
       		d4 = num%10;
       		num /= 10;
    	    d3 = num%10;
 	       num/= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1 = num%10;
 	       num/= 10;
			if((d1<d2) && (d2>d3) && (d3<d4) && (d4>d5) && (d5<d6)
			&& (d6>d7) ){
				return 'M';
			}
			if((d1>d2) && (d2<d3) && (d3>d4) && (d4<d5) && (d5>d6)
			&& (d6<d7)) {
				return 'V';
			}
	}
	}			
	if(count==8){
    	while (num >= 10000000) { 
       		d8 = num%10;
       		num /= 10;
       		d7 = num%10;
       		num /= 10;
       		d6 = num%10;
       		num /= 10;
       		d5 = num%10;
       		num /= 10;
       		d4 = num%10;
       		num /= 10;
    	    d3 = num%10;
 	       num/= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1 = num%10;
 	       num/= 10;
			if((d1<d2) && (d2>d3) && (d3<d4) && (d4>d5) && (d5<d6)
			&& (d6>d7) && (d7<d8) ){
				return 'M';
			}
			if((d1>d2) && (d2<d3) && (d3>d4) && (d4<d5) && (d5>d6)
			&& (d6<d7) && (d7>d8) ){
				return 'V';
			}
		}			
		}	
	if(count==9){
    	while (num >= 100000000) { 
       		d9 = num%10;
       		num /= 10;
       		d8 = num%10;
       		num /= 10;
       		d7 = num%10;
       		num /= 10;
       		d6 = num%10;
       		num /= 10;
       		d5 = num%10;
       		num /= 10;
       		d4 = num%10;
       		num /= 10;
    	    d3 = num%10;
 	       num/= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1 = num%10;
 	       num/= 10;
			if((d1<d2) && (d2>d3) && (d3<d4) && (d4>d5) && (d5<d6)
			&& (d6>d7) && (d7<d8) && (d8>d9) ){
				return 'M';
			}
			if((d1>d2) && (d2<d3) && (d3>d4) && (d4<d5) && (d5>d6)
			&& (d6<d7) && (d7>d8) && (d8<d9) ){
				return 'V';
			}
		}
	}		
	if(count==10){
    	while (num >= 1000000000) { 
       		d10 = num%10;
       		num /= 10;
       		d9 = num%10;
       		num /= 10;
       		d8 = num%10;
       		num /= 10;
       		d7 = num%10;
       		num /= 10;
       		d6 = num%10;
       		num /= 10;
       		d5 = num%10;
       		num /= 10;
       		d4 = num%10;
       		num /= 10;
    	    d3 = num%10;
 	       num/= 10;
    	    d2 = num%10;
 	       num/= 10;
    	    d1 = num%10;
 	       num/= 10;
			if((d1<d2) && (d2>d3) && (d3<d4) && (d4>d5) && (d5<d6)
			&& (d6>d7) && (d7<d8) && (d8>d9) && (d9<d10)){
				return 'M';
			}
			if((d1>d2) && (d2<d3) && (d3>d4) && (d4<d5) && (d5>d6)
			&& (d6<d7) && (d7>d8) && (d8<d9) && (d9>d10)){
				return 'V';
			}	
	}
	}
		
	return 'N';
}
	

void count_valid_mv_numbers(int a, int b) {
	// TODO(student): count the number of valid mountain ranges and valley
	// ranges in the range [a, b] and print out to console using the format
	//in Requirement 4 of the homework prompt
	
	int mon=0, val=0;
	int i;
	for(i=a;i<b+1;i++){
		char value = classify_mv_range_type(i);
		if(value=='M'){
			mon++;
		}
		else if(value=='V'){
			val++;
		}
	}

	cout<<"There are "<<mon<<" mountain ranges and "<<val<<" valley ranges between "<<a<<" and "<<b<<"."<<endl;
}