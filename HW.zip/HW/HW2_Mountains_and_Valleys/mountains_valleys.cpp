#include <iostream>
#include "functions.h"
using namespace std;

int main() {
	bool work=true;
	while(work==true){
	int a, b;

	// TODO(student): print prompt for input
	cout<<"Enter numbers 10 <= a <= b < 10000: ";
	
	// TODO(student): read the numbers from standard input
	cin>>a;
	cin>>b;

	// TODO(student): validate input (and reprompt on invalid input)
	bool value = is_valid_range(a, b);
	if(value==true){
		count_valid_mv_numbers(a,b);
		work=false;
	}
	else if(value==false){
		cout<<"Invalid Input"<<endl;
	}

	// TODO(student): compute and display solution
	
	}
	return 0;
}