#include <iostream>
#include <string>
#include "./string_calculator.h"

using namespace std;
using std::string;

unsigned int digit_to_decimal(char digit) {////////////////////////Convert
    int num=0;
    // TODO(student): implement
    if((digit>=48) && (digit<=57)){
        num = (digit-48);
    }
    else if((digit>=58) && (digit<=67)){
        num = (digit-48);
    }
    else{
        cout<<digit<<" digit WRONG?"<<endl;
        throw std::invalid_argument("Wrong character\n");
    }
    return num;
}

char decimal_to_digit(unsigned int decimal) {
    char num=0;
    // TODO(student): implement
    if (decimal<=10){
        num = (decimal+48);
    }
    else if(decimal<10){
        num = (decimal-48);
    }
    else{
        cout<<decimal<<" dec wrong?"<<endl;
        throw std::invalid_argument("Wrong character\n");
    }
    return num;
}

string trim_leading_zeros(string num) {/////////////////////??////Trim Zeros
    // TODO(student): implement
    if(num[0]=='-'){
        while(num[1]=='0'){  
            num.erase(1,1);  
            if((num[0]=='-')&&!num[1]){
                return "0";
            }  
            if (!num[1]){//if does not exist
                break;
            }
        }
        return num;
    }
    while(num[0]=='0'){  
        num.erase(0,1);    
        if (!num[1]){//if does not exist
            break;
        }
    }
    return num;
}

string add(string lhs, string rhs) {////////////////////////////////////ADD
    string tot="";
    char r_end='0',l_end,carry='0';
    unsigned int temp=0;
    size_t tot_size;
    bool sign_b=false;
    // TODO(student): implement
    //if one is pos and other is neg, SEND TO SUB

    if( ((lhs[0]=='0') || (rhs[0]=='0')) && ((lhs[1]!='0') && (rhs[1]!='0'))){
        
    }
    else{
        lhs=trim_leading_zeros(lhs);
        rhs=trim_leading_zeros(rhs);
    }
    if((lhs[0]=='-')&&(rhs[0]=='-')){
        lhs.erase(0,1), rhs.erase(0,1);
        sign_b = true;
    }
    if(lhs.size() > rhs.size()){
        tot_size = lhs.size();
    }
    else{
        tot_size = rhs.size();
    }
    while(lhs.size() < tot_size){
        lhs = '0'+lhs;
    }
    while(rhs.size() < tot_size){
        rhs = '0'+rhs;
    }
    lhs = '0'+lhs;
    rhs = '0'+rhs;
    for(int x=lhs.length()-1; x >= 0 ; x--){
        r_end = rhs[x];
        l_end = lhs[x];
        temp = digit_to_decimal(r_end) + digit_to_decimal(l_end);
        temp = temp + digit_to_decimal(carry);
        if(temp>=10){
            carry = '1';
            temp = temp - 10;
        }
        else{
            carry = '0';
        }
        tot = decimal_to_digit(temp)+tot;
        if(x==0){
            break;
        }
    }
    while(tot[0]=='0'){
        if(!tot[1]){
            break;
        }
        tot.erase(0,1);    
    }
    if(sign_b==true){
        tot="-" + tot;
    }
    if (tot[0] != '0' && tot[0] && tot[1]) {
        tot=trim_leading_zeros(tot);
    }
    else{
        return tot;
    }
    return tot;
}


string multiply(string lhs, string rhs) {////////////////////////////MULTIPLY
    // TODO(student): implement
     string tot1="",partial_tot="",totf="";
    char r_end='0',l_end,carry='0';
    unsigned int temp=0;
    size_t tot_size;
    bool sign_b=false;
    unsigned int temp_num=1; 
    // TODO(student): implement

    if( ((lhs[0]=='0') || (rhs[0]=='0')) && ((lhs[1]!='0') && (rhs[1]!='0'))){
        
    }
    else{
        lhs=trim_leading_zeros(lhs);
        rhs=trim_leading_zeros(rhs);
    }
    if((lhs[0]=='-')&&(rhs[0]=='-')){
        lhs.erase(0,1), rhs.erase(0,1);
        sign_b = false;
    }
    else if((lhs[0]=='-')&&(rhs[0]!='-')){
        lhs.erase(0,1);
        sign_b = true;
    }
    else if((lhs[0]!='-')&&(rhs[0]=='-')){
        rhs.erase(0,1);
        sign_b = true;
    }
    if(lhs.size() > rhs.size()){ //same size
        tot_size = lhs.size();
    }
    else{
        tot_size = rhs.size();
    }
    while(lhs.size() < tot_size){
        lhs = '0'+lhs;
    }
    while(rhs.size() < tot_size){
        rhs = '0'+rhs;
    }
    lhs = '0'+lhs;
    rhs = '0'+rhs;
    for(int x=rhs.length()-1; x>=0 ;x--){
        partial_tot="";
        carry='0';
        temp_num=0;
        for(size_t j=x;j<rhs.length()-1;j++){
            partial_tot +='0';
        }
        for(int i=lhs.length()-1; i >= 0;i--){
            temp=0;
            r_end = rhs[x];
            l_end = lhs[i];
            temp = digit_to_decimal(r_end) * digit_to_decimal(l_end);
            temp = temp + digit_to_decimal(carry);
            
            if(temp>=10){
                partial_tot = decimal_to_digit(temp%10)+partial_tot;
                temp_num = temp/10;
                carry = temp_num+48;
                //partial_tot = decimal_to_digit(temp_num) + partial_tot;
                //temp=temp-((decimal_to_digit(carry)));
            }
            else{
                partial_tot = decimal_to_digit(temp)+partial_tot;
                carry = '0';
                //partial_tot = decimal_to_digit(temp%10);
                temp_num = temp/10;
                //partial_tot = decimal_to_digit(temp_num) + partial_tot;
                
            }
            //tot1 = add(tot1,partial_tot);
            
            if(i==0){
                break;
            }

        }
        tot1 = add(tot1,partial_tot);
    }
    totf=tot1;
    while(totf[0]=='0'){
        if(!totf[1]){
            break;
        }
        totf.erase(0,1);    
    }
    if(sign_b==true){
        totf="-" + totf;
    }
    if (totf[0] != '0' && totf[0] && totf[1]) {
        totf=trim_leading_zeros(totf);
    }
    else{
        return totf;
    }
    return totf;
}
