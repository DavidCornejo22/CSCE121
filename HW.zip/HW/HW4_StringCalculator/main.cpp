#include <iostream>
#include <string>
#include <limits>
#include "./string_calculator.h"

using namespace std;
using std::string;

int main() {
    cout << "String Calculator" << endl;
    cout << "\"q\" or \"quit\" or ctrl+d to exit" << endl;
    
    // TODO(student): implement the UI
string num1,num2;
char sym;    
bool a=true;

while(a==true){
    cout << "\n>> ";
    cin >> num1;
    if((num1=="q")||(num1=="quit")||cin.eof()){
        cout<<"\nfarvel!\n";
        return 0;
    }
    cin >> sym;
    cin >> num2;



    if(sym=='+'){
        cout<<"\nans =\n\t"<<add(num1,num2);
    }
    else if(sym=='*'){
        //multply function 
        //Sub = Add but opposite OR just add a symbol in front of tot
        cout<<"\nans =\n\t"<<multiply(num1,num2); //FINISH ADD FIRST
        
    }
    else{
        
    }

    }
}

