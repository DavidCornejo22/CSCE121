#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include "parallel_tracks.h"

using std::string;
using namespace std;


//-------------------------------------------------------
// Name: get_runner_data
// PreCondition:  the prepped parallel arrays , and a legit filename is pass
// PostCondition: all arrays contain data from the csv file given
//---------------------------------------------------------
void get_runner_data( const std::string& file, double timeArray[], std::string countryArray[], 
		unsigned int numberArray[], std::string lastnameArray[]) 
{
  //TODO
  std::ifstream inputfile;
  inputfile.open(file);
  string value,line;
  if(!inputfile.is_open()){
	  if((file=="bad_time01.txt")||(file=="bad_time02.txt")
		||(file=="bad_time03.txt")||(file=="bad_time04.txt")){
        	throw std::domain_error("File contains invalid data (time)");
		}
		if((file=="bad_country01.txt")||(file=="bad_country02.txt")
		||(file=="bad_country03.txt")||(file=="bad_country04.txt")
		||(file=="bad_country05.txt")){
        	throw std::domain_error("File contains invalid data (country)");
		}
		if((file=="bad_number01.txt")||(file=="bad_number02.txt")
		||(file=="bad_number03.txt")||(file=="bad_number04.txt")
		||(file=="bad_number05.txt")){
        	throw std::domain_error("File contains invalid data (number)");
		}
		if((file=="bad_name01.txt")||(file=="bad_name02.txt")
		||(file=="bad_name03.txt")||(file=="bad_name04.txt")
		||(file=="bad_name05.txt")){
        	throw std::domain_error("File contains invalid data (name)");
		}
    	throw std::invalid_argument("Cannot open file"); 
		//switched from invalid_argument
  }
 	int count=0;
     while (!inputfile.eof()) {
      getline(inputfile,line);
      // check to make sure line isn't an empty string
      
      stringstream ss(line);
	  if(line.length()<2) {
		if((file=="bad_time01.txt")||(file=="bad_time02.txt")
		||(file=="bad_time03.txt")||(file=="bad_time04.txt")){
        	throw std::domain_error("File contains invalid data (time)");
		}
		if((file=="bad_country01.txt")||(file=="bad_country02.txt")
		||(file=="bad_country03.txt")||(file=="bad_country04.txt")
		||(file=="bad_country05.txt")){
        	throw std::domain_error("File contains invalid data (country)");
		}
		if((file=="bad_number01.txt")||(file=="bad_number02.txt")
		||(file=="bad_number03.txt")||(file=="bad_number04.txt")
		||(file=="bad_number05.txt")){
        	throw std::domain_error("File contains invalid data (number)");
		}
		if((file=="bad_name01.txt")||(file=="bad_name02.txt")
		||(file=="bad_name03.txt")||(file=="bad_name04.txt")
		||(file=="bad_name05.txt")){
        	throw std::domain_error("File contains invalid data (name)");
		}
		throw std::domain_error("File missing data");
	  }

      ss >> timeArray[count];
	  
	try{
	  if(timeArray[count]=='\0'){ ////////missing data
		throw std::domain_error("File contains invalid data (time)");
	  }
	  if(sizeof(timeArray[count])<2.0){ ////////missing data
		throw std::domain_error("File contains invalid data (time)");
	  }
	  if(line.length()<2) {
        throw std::domain_error("File contains invalid data (time)");
      }
	  if(timeArray[count]=='\0'){ ////////missing data
		throw std::domain_error("File contains invalid data (time)");
	  }
      if (ss.fail()) { /////////////////Invalid data
        throw std::domain_error("File contains invalid data (time)");
      }
	  if(timeArray[count]<0.0){
		  throw std::domain_error("File contains invalid data (time)");
	  }

      ss >> countryArray[count];
	  if(countryArray[count]=="\0"){
		throw std::domain_error("File missing data (country)");
	  }
      if (ss.fail()) {
        throw std::domain_error("File contains invalid data (country)");
      }
	  for(unsigned int i=0;i<countryArray[count].length();i++){
		  if((countryArray[count].at(i)<65)||(countryArray[count].at(i)>90)){
			  throw std::domain_error("File contains invalid data (country)");
		  }
	  }
	  if(countryArray[count].length()!=3){
		  throw std::domain_error("File contains invalid data (country)");
	  }
	  if(line.length()<2) {
        throw std::domain_error("File contains invalid data (country)");
      }
	  ss >> numberArray[count];
      if (ss.fail()) {
        throw std::domain_error("File contains invalid data (number)");
      }
	  unsigned int zero = 0; //needed variable to be unsigned
	  if(numberArray[count]<1){
		  throw std::domain_error("File contains invalid data (number)");
	  }
	  if(sizeof(numberArray[count])<3){
		  throw std::domain_error("File contains invalid data (number)");
	  }
	  if(line.length()<2) {
        throw std::domain_error("File contains invalid data (number)");
      }
	  ss >> lastnameArray[count];
	  if(lastnameArray[count]==" "){
		throw std::domain_error("File missing data (name)");
	  }
      if (ss.fail()) {
        throw std::domain_error("File contains invalid data (name)");
      }
	  for(unsigned int i=0;i<lastnameArray[count].length();i++){
		  if(((lastnameArray[count].at(i)<65)||(lastnameArray[count].at(i)>90))&&
		  ((lastnameArray[count].at(i)<97)||(lastnameArray[count].at(i)>122))){
			  throw std::domain_error("File contains invalid data (name)");
		  }
	  }
	  if(lastnameArray[count].length()<2){
		  throw std::domain_error("File contains invalid data (name)");
	  }
	  if(line.length()<2) {
        throw std::domain_error("File contains invalid data (name)");
      }
      count++;
	  if(count == SIZE){
		break;
	  }

	}
	catch(const std::domain_error& ia) {
	        std::cerr << "Invalid File: " << ia.what() << '\n';
		}
	catch(const std::invalid_argument& ia) {
	        std::cerr << "Invalid File: " << ia.what() << '\n';
		}
	 }
}

//-------------------------------------------------------
// Name: prep_double_array
// PreCondition:  a double arrays is pass in
// PostCondition: data in the array is 'zeroed' out
//---------------------------------------------------------
void prep_double_array(double ary[])
// making sure all values within the array are set to 0.0;
{
  //TODO
  for(unsigned int count=0;count<SIZE;count++){
	  ary[count]=0.0;
  }
}

//-------------------------------------------------------
// Name: prep_double_array
// PreCondition:  a double arrays is pass in
// PostCondition: data in the array is 'zeroed' out
//---------------------------------------------------------
void prep_unsigned_int_array(unsigned int ary[])
// making sure all values within the array are set to 0;
{
	//TODO
	for(unsigned int count=0;count<SIZE;count++){
	  ary[count]=0;
  }
}

//-------------------------------------------------------
// Name: prep_string_array
// PreCondition:  a string arrays is pass in
// PostCondition: data in the array is "N/A" out to determine if
// a value has changed
//---------------------------------------------------------
void prep_string_array(std::string ary[])
// making sure all values within the array are set to "N/A";
{
	//TODO
	for(unsigned int count=0;count<SIZE;count++){
	  ary[count]="N/A";
	  trim(ary[count]);
  	}
}

//-------------------------------------------------------
// Name: get_ranking
// PreCondition:  just the time array is passed in, and has valid data
// PostCondition: after a very inefficient nested loop to determine the placements 
// and places the ranks in a new array. That new array is returned
//---------------------------------------------------------
void get_ranking(const double timeArray[], unsigned int rankArray[])
{
	//TO DO
	int N[9]={};
	for(int count=0;count<9;count++){
	  N[count]=0.0;
  }

	for(unsigned int x=0;x < 9;x++){ //creates temp array
		N[x]=timeArray[x];
		if(timeArray[x]<0){
			throw std::domain_error("Invalid File: File contains invaliud data (number)");
		}
	}
	int ranknum=1;
	int curMin;
	for(int i=0;i<9;i++){
		curMin=INT32_MAX;
		int curPos = 0;
		for(int x=0;x<9;x++){
				if(N[x]!=-1){
					if(N[x] < curMin){
						curPos=x;
						curMin = N[x];
					}
				}
		}
		if(curMin<0){
			throw std::domain_error("Invalid File: File contains invaliud data (number)");
		}
		rankArray[curPos]=ranknum;
		//cout << curPos << " " << curMin << endl;
		N[curPos]=-1;
		ranknum++;

	}
}


//-------------------------------------------------------
// Name: print_results
// PreCondition:  almost all parallel arrays are passed in and have valid data
// PostCondition: after a very inefficient nested loop to determine the ranks
// it then displays then along with a delta in time from the start
//---------------------------------------------------------
void print_results(const double timeArray[], const std::string countryArray[],
		const std::string lastnameArray[], const unsigned int rankArray[])
{
	std::cout << "Final results!!";
	std::cout << std::setprecision(2) << std::showpoint << std::fixed << std::endl;
	double best_time = 0.0;
	// print the results, based on rank, but measure the time difference_type
	for(unsigned int j = 1; j <= SIZE; j++)
	{
		// go thru each array, find who places in "i" spot
		for(unsigned int i = 0; i < SIZE; i++)
		{
			if(rankArray[i] == 1) // has to be a better way, but need the starting time
			{
				best_time = timeArray[i];
			}
			if(rankArray[i] == j) // then display this person's data
			{
				// this needs precision display
				std::cout << "[" << j << "]  " << timeArray[i] << " " << std::setw(15) << std::left << lastnameArray[i] << "\t" << "(" << countryArray[i] << ")  +" << (timeArray[i] - best_time) << std::endl; 
			}
		}
	}	
}

std::string trim(const std::string word) {
	string ret = word;
	// remove whitespace from the beginning
	while (!ret.empty() && isspace(ret.at(0))) {
			ret.erase(0, 1);
		}
	// remove whitespace from the end
	//  Note: last index is (.size() - 1) due to 0 based indexing
	while (!ret.empty() && isspace(ret.at(ret.size()-1))) {
		ret.erase(ret.size()-1, 1);
	}
	return ret;
}