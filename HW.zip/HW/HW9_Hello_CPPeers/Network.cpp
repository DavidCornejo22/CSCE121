/*This code is copyrighted (c) 2021 by
 * Texas A&M Computer Science
 *
 *	There will be RIGOROUS cheat checking on your exams!!
 *	DON'T POST ANYWHERE!! such as CHEGG, public Github, etc
 *  You will be legally responsible.*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include "Network.h"

using namespace std;

Network::Network(): users(), posts(), tags() {
  // empty containers of vectors already created
  // no implementation is needed here
}

void Network::loadFromFile(string fileName) {
  // TODO(student): load user and post information from file
  ifstream inFS;
  inFS.open(fileName);
  if (!inFS.is_open()) {
    throw std::invalid_argument("File could not be opened");
  }

  string line;
  string temp;
  string userName;
  unsigned int postId;
  string postUser;
  string postText;

  while(!inFS.eof()) {
    getline(inFS, line);
    stringstream ss(line);
    ss >> temp;
    if (temp == "") {
      break;
    }
    else if (temp == "User") {
      ss >> userName;
      try
      {
        addUser(userName);
      }
      catch(const std::exception& e)
      {
        throw std::runtime_error("User entry not following the specified format");
      }
      temp = "";
    }
    else if (temp == "Post") {
      ss >> postId;
      ss >> postUser;
      getline(ss, postText);
      try
      {
        addPost(postId, postUser, postText);
      }
      catch(const std::exception& e)
      {
        throw std::runtime_error("Post entry not following the specified format");
      }
      temp = "";
    }
    else {
      throw std::runtime_error("Unknown entry");
    }
  }
}

void Network::addUser(string userName) {
  // TODO(student): create user and add it to network
  for (unsigned int i = 0; i < userName.length(); i++) {
    if ((userName.at(i) >= 65) && (userName.at(i) <= 90)) {
      userName.at(i) = userName.at(i) + 32;                              
    }
  }

  for (unsigned int j = 0; j < users.size(); j++) {
    User testUser = *users.at(j);
    if (userName == testUser.getUserName()) {
      throw std::invalid_argument("User already exists");               
    }
  }
  
  User* newUser = new User(userName);
  users.push_back(newUser);

  std::cout << "Added User " << userName << std::endl;
}

void Network::addPost(unsigned int postId, string userName, string postText) {
  // TODO(student): create post and add it to network
  for (unsigned int i = 0; i < posts.size(); i++) {
    if (posts.at(i)->getPostId() == postId) {
      throw std::invalid_argument("PostId already exists");            
    }
  }
  int count = 0;
  int num = 0;
  for (unsigned int j = 0; j < users.size(); j++) {
    if (users.at(j)->getUserName() == userName) {
      count = 1;
      num = j;
    }
  }
  if (count == 0) {
    throw std::invalid_argument("User not found");                  
  }

  Post* newPost = new Post(postId, userName, postText);             
  posts.push_back(newPost);                                             
  users.at(num)->addUserPost(newPost);                               

  int countTag = 0;
  vector<string> listOfTags = newPost->findTags();                    
  for (unsigned int i = 0; i < listOfTags.size(); i++) {           
    for (unsigned int j = 0; j < tags.size(); j++) {
      if (listOfTags.at(i) == tags.at(j)->getTagName()) {
        tags.at(j)->addTagPost(newPost);
        countTag = 1;
      }
    }
    if (countTag == 0) {                                              
      try
      {
        Tag* newTag = new Tag(listOfTags.at(i));                 
        tags.push_back(newTag);                                     
        newTag->addTagPost(newPost);                               
      }
      catch(const std::exception& e)                         
      {
        std::cerr << e.what() << '\n';
      }
    }
    countTag = 0;
  }

  std::cout << "Added Post " << postId << " by " << userName << std::endl;
}



vector<Post*> Network::getPostsByUser(string userName) {
  // TODO(student): return posts created by the given user
  if (userName == "") {
    throw std::invalid_argument("userName is empty");              
  }
  int count = 0;
  int num = 0;
  for (unsigned int i = 0; i < users.size(); i++) {
    if (userName == users.at(i)->getUserName()) {
      count = 1;
      num = i;
    }
  }
  if (count == 0) {
    throw std::invalid_argument("userName not found");      
  }

  return users.at(num)->getUserPosts();                         
}



vector<Post*> Network::getPostsWithTag(string tagName) {
  // TODO(student): return posts containing the given tag
  if (tagName == "") {
    throw std::invalid_argument("tagname is empty");            
  }
  int count = 0;
  unsigned int num = 0;
  for (unsigned int i = 0; i < tags.size(); i++) {
    if (tagName == tags.at(i)->getTagName()) {
      count = 1;
      num = i;
    }
  }
  if (count == 0) {
    throw std::invalid_argument("tagname not found");        
  }

  return tags.at(num)->getTagPosts();                      
}



vector<string> Network::getMostPopularHashtag() {
  // TODO(student): return the tag occurring in most posts
  vector<Post*> pop_tag;
  vector<Post*> test_tag;
  vector<string> max_tag;
  int index = 0;

  if (tags.size() == 0) {
    return max_tag;
  }

  pop_tag = tags.at(0)->getTagPosts();
  max_tag.push_back(tags.at(0)->getTagName());
  for (unsigned int i = 0; i < tags.size(); i++) {
    test_tag= tags.at(i)->getTagPosts();
    if (test_tag.size() > pop_tag.size()) {
      pop_tag = test_tag;
      max_tag.pop_back();
      max_tag.push_back(tags.at(i)->getTagName());
      index = i;
    }
  }
  pop_tag = tags.at(index)->getTagPosts();
  for (unsigned int j = index+1; j < tags.size(); j++) {
    test_tag = tags.at(j)->getTagPosts();
    if (pop_tag.size() == test_tag.size()) {
      max_tag.push_back(tags.at(j)->getTagName());
    }
  }

  return max_tag;
}

/**
  * Destructor
  * Do not change; already implemented.
  */
Network::~Network() {
  for (unsigned int i = 0; i < users.size(); ++i) {
    delete users.at(i);
  }
  for (unsigned int i = 0; i < tags.size(); ++i) {
    delete tags.at(i);
  }
  for (unsigned int i = 0; i < posts.size(); ++i) {
    delete posts.at(i);
  }
}
