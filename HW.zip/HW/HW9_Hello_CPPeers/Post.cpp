/*This code is copyrighted (c) 2021 by
 * Texas A&M Computer Science
 *
 *	There will be RIGOROUS cheat checking on your exams!!
 *	DON'T POST ANYWHERE!! such as CHEGG, public Github, etc
 *  You will be legally responsible.*/

#include <iostream>
#include <string>
#include <stdexcept>
#include "Post.h"
#include <sstream>

using namespace std;
using std::string;
using std::vector;
using std::istringstream;

Post::Post(unsigned int postId, string userName, string postText)
  : postId(postId), userName(userName), postText(postText) {
  if (postId == 0 || userName == "" || postText == "") {
    throw std::invalid_argument("post constructor: invalid parameter values");
  }
}

unsigned int Post::getPostId() {
  return postId;
}

string Post::getPostUser() {
  return userName;
}

string Post::getPostText() {
  return postText;
}

vector<string> Post::findTags() {
  // TODO(student): extracts candidate tags based on occurrences of # in the post
  int count=0;
  vector<string> tags; //variable name
  istringstream text(getPostText());  //varaible name

  while(!text.eof()){
    string tag="";
    text>>tag;
    if(tag.at(0)=='#'){
      for(unsigned int i=0;i<tag.size();i++){
        tag.at(i)=tolower(tag.at(i));
        if(tag.at(i)=='.'||tag.at(i)=='?'||tag.at(i)=='!'||tag.at(i)==','){
          tag.erase(i,1);
          i--; //makes match updated tag size
        }
      }
      tags.push_back(tag);
    }


  }
  return tags;
}
