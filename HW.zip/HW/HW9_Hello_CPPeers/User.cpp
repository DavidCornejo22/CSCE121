/*This code is copyrighted (c) 2021 by
 * Texas A&M Computer Science
 *
 *	There will be RIGOROUS cheat checking on your exams!!
 *	DON'T POST ANYWHERE!! such as CHEGG, public Github, etc
 *  You will be legally responsible.*/

#include <string>
#include <stdexcept>
#include "User.h"

using std::string;
using std::vector;

User::User(string userName) /* TODO(student): initialize */
:userName(userName),userPosts({}) {
  if(userName=="" || userName.size()==0 || userName.empty()){
      throw std::invalid_argument("too small");
  }
  if(userName.at(0)<'a' || userName.at(0)>'z'){
      throw std::invalid_argument("not lowercase");
  }
  for(int i=2;i<this->userName.size()-1;i++){
    if(!(userName.at(i)<('a')||userName.at(i)<('z'))){
      throw std::invalid_argument("username uppercase");
    }
  }
 //this->userName=userName; 
}

string User::getUserName() {
  // TODO(student): implement getter
  return userName;
}

vector<Post*>& User::getUserPosts() {
  // TODO(student): implement getter
  return userPosts;
}

void User::addUserPost(Post* post) {
  // TODO(student): add post to user posts
  //if post == nullptr
  if(post==nullptr){
    throw std::invalid_argument("post is nullptr");
  }
  userPosts.push_back(post);
}
