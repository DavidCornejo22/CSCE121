#ifndef BOAT_H
#define BOAT_H
#include <iostream>

using namespace std;

namespace boat {
  class Dealership {
      public:
         Dealership();
         void Sell();
         int GetStock();
      private:
         int stock;
   };

   Dealership::Dealership() {
      stock = 50;
   }   

   void Dealership::Sell() {
      stock -= 1;
      cout << "Sold boat" << endl;
   }

   int Dealership::GetStock() {
      return stock;
   }
}
#endif