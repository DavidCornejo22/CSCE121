#include <iostream>
using namespace std;

int* get_array_ordered_by_frequency(int* a, unsigned int size_a, unsigned int& new_array_size){
  //loop to create new array, of number of different variables
  
  //then create 2d array, based on iterations of each number
}
int** remove_allzeros_rows(int** matrix,int nrows,int ncols,int& new_nrows){
  if(nrows==0||ncols==0){
    throw std::invalid_argument("Rows OR Cols is 0");
  }
  int count=0;
  //int* arr=new int[nrows];
  for(int i=0;i<nrows;i++){
    for(int j=0;j<ncols;j++){
      if(matrix[i][j]!=0){
        count++;
        break;
      }
    }
  }
  new_nrows=count;
  int* no_rows= new int(nrows-count);

  int nrows_count=0;
  int temp_count=0;
  for(int i=0;i<nrows;i++){
    nrows_count=0;
    for(int j=0;j<ncols;j++){
      if(matrix[i][j]!=0){
        nrows_count++;
      }
    }
    if(nrows_count==0){
      no_rows[temp_count]=i;
      temp_count++;
    }
  }
  int** new_matrix=new int*[new_nrows];
  for(int k=0;k<nrows;k++){
    new_matrix[k]=new int[ncols];
  }

  int test=0;
  int q=0;
  for(int i=0;i<nrows-test;i++){
    test=0;
    for(int j=0;j<test;j++){
      test++;
    }
    if(test==0){
      for(int k=0;k<ncols;k++){
        new_matrix[q][k]=matrix[i][k];
      }
      q++;
    }
  }
  return new_matrix;
}
int main() {
  int nrows=3;
  int ncols=2;
  int new_nrows=0;
  int** matrix=new int*[nrows];
  for(int i=0;i<nrows;i++){
    matrix[i]=new int[ncols];
  }
  //int matrix[nrows][ncols]={{0,0},{1,0},{2,3}};
  matrix[0][0]=0;
  matrix[0][1]=0;
  matrix[1][0]=1;
  matrix[1][1]=0;
  matrix[2][0]=2;
  matrix[2][1]=3;
  int **new_matrix=remove_allzeros_rows(matrix,nrows,ncols,new_nrows);
  for(int i=0;i<nrows;i++){
    for(int j=0;j<ncols;j++){
      cout<<new_matrix[i][j]<<" ";
    }
    cout<<endl;
  }
  cout<<endl;
  return 0;
}
