#ifndef CAR_H
#define CAR_H
#include <iostream>

using namespace std;

namespace car {
  class Dealership {
      public:
         Dealership();
         void Sell();
         int GetStock();        
      private:
         int stock;
   };

   Dealership::Dealership() {
      stock = 20;
   }   

   void Dealership::Sell() {
      stock -= 1;
      cout << "Sold car" << endl;
   }

   int Dealership::GetStock() {
      return stock;
   }
}
#endif