// TODO: Implement this source file
#include <iostream>
#include <fstream>
#include "MyString.h"
//#include "Rover.h"
MyString::MyString():cap(1),len(0),content(new char[cap]) { //Constructor
    // cap=1;
    // len=0;
    // content=new char[cap];
}
void MyString::clear() { ////////////////////////////////////// CLEAR
    if(this->size()==0||content==nullptr){
        return;
    }
    delete[] content;
    content = new char[1];
    content[0]='\0';
    len=0;
    cap=1;
    //delete whole arrary, replace with one char null
}
MyString::MyString(const MyString& str):cap(str.cap),len(str.len),content(new char[str.cap]){
    // cap=str.cap;
    // len=str.len;
    for(int i=0;i<len;i++){
        content[i]=str.at(i);
    }
    content[len]='\0';
}
//1) find size of s
//2) make array that size
//3) fill in array, with same as s
MyString::MyString(const char* s):cap(1),len(0),content(new char[cap]){ //copy arrary of characters
    int i=0;
    // cap=1;
    // len=0;
    // content = new char[cap];
    if(s==nullptr){
        return;
        //throw std::logic_error("null not valid");
    }
    while(s[i]!='\0'){
        content[i]=s[i];
        i++;
        len+=1;
        if(cap==len){
            cap*=2;
            char* temp=new char[cap];
            for(int j=0;j<len;j++){
                temp[j]=content[j];
            }
            //content=temp;
            std::swap(content, temp);
            delete[] temp;
        }
    }
    content[len]='\0';
}
//ALWAYS have something in the char *  variable (except after the destructor)
MyString::~MyString() {
    // for(int i=0;i<cap;i++){
    //     delete content[i];
    // }
    delete[] content;
}
unsigned int MyString::size()const {
    //**How many character is array, we are actually using
    //gonna have one extra byte ("dog\0"), so decrease by 1
    return length();
}
void MyString::resize(int n){
    //resize to new number
    if(n<0){
    }
    if(n<len){
        for(int i=n;i<len;i++){
            content[i]='\0';
        }
        len=n;
        cap=cap*2;
    }
    if(n>len){
        for(int i=len;i<n;i++){
            content[i]='\0';
        }
        len=n;
        cap=cap*2;
    }
}
int MyString::length()const { //same as size()
    return len;
}
unsigned int MyString::capacity() const{
    //how big arrary is, at least one bigger than size
    //loop through array. EVEN take in \0 
    return cap;
}
//returns the internal character array’s reference 
//because it is actually a c-string on the inside, 
//so remember the null terminator
const char* MyString::data() const {///////////////////// DATA
    
    return content;
}
//if not empty, clear
bool MyString::empty()const { ////////////////////////// EMPTY
    if(size()==0){
        return true;
    }
    return false;
}
char MyString::front()const { ////////////////////////// FRONT
    return content[0];
}
char MyString::at(int pos)const { ////////////////////// AT
    if((unsigned int)pos>=size()){
        throw std::out_of_range("pos greater than string size");
    }
    return content[pos];
   
}
ostream& operator<<(ostream& out, const MyString& string){ //// <<
    if(string.empty()==true||string.size()==0){
        out<<"";
        return out;
    }
    for(int i=0;i<string.length();i++){
        //std::cout<<at.at(i);//<<",";
        out<<string.at(i);
    }
    //out<<std::endl; 
    return out;
}
MyString& MyString::operator =(const MyString& str){ //////////// =
    //copy constructor
    //copy of len and cap, pass over
        //transfer current pointer, to the current array
    
    if (this != &str) {
        cap=str.cap; //copies all the temp variables, to the MyString variables
        len=str.len;
        delete[] content;
        content=new char[cap];
        // return *this;
        for(int i=0;i<len;i++){
            content[i]=str.at(i);
        }
        content[len]='\0';
    }
    return *this;
}
MyString& MyString::operator +=(const MyString& str){/////////////////////// +=
    //dogstr+=catstr;
        //copy dog, cats into new string
    if(cap<(len+str.len + 1)){ //corrects new cap length
        while(cap<(len+str.len +1)) {
            cap*=2;
        }
        if(content==nullptr||empty()){
            delete [] content;
            content=new char[cap];
        }
        char* temp=new char[cap];
        for(int j=0;j<len;j++){ //same as copy constructor
            temp[j]=content[j];
        }
        // delete[] content;//free up mem
        // content=temp;
        std::swap(content, temp);
        delete[] temp;
    }
    for(int i=0;i<str.len;i++){ //adds on to ends of current array
        content[len+i]=str.content[i];
    }
    len=str.len+len;
    content[len]='\0';
    return *this;
}
bool operator== (const MyString& lhs, const MyString& rhs){//////////////////// ==
    if(lhs.size()>rhs.size()){
        return false;
    }
    else if(lhs.size()<rhs.size()){
        return false;
    }
    for(unsigned int i=0;i<lhs.size();i++){
        if(lhs.at(i)!=rhs.at(i)){
            return false;
        }
    }
    return true;
}
MyString operator+ (const MyString& lhs, const MyString& rhs){////////////////// +
    
    char* content=new char[(lhs.size()+rhs.size())*2];
    unsigned int big_size=lhs.size()+rhs.size();
    for(unsigned int i=0;i<big_size;i++){
        //content[i]=lhs.at(i);
        if(i>=lhs.size()){
            content[i]=rhs.at(i-lhs.size());
        }
        else{
            content[i]=lhs.at(i);
        }
    }
    MyString newstring(content);
    return newstring;
}
int MyString::find(const MyString& str,size_t pos) const{ ////// FIND
    //two loops
    //return -1, if cannot find it
    size_t ret=-1;
    bool test;
    int num;
    if(pos>(size_t)len){
        return ret;
    }
    for(int i=pos;i<len;i++){
        //if i==first char of str
        //then loop through again
        //check if the following spots are the same
        if(str.at(0)==content[i]){
            test=true;
            num=0;
            for(int x=i;(unsigned int)x<(i+str.size());x++){
                if(str.at(num)!=content[x]){
                    test=false;
                    break;
                }
                num++;
            }
            if(test==true){
                return i;
                
            }
        }
    }
    return ret;
}

