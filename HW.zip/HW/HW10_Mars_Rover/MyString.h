// TODO: Implement this header file
#ifndef MYSTRING_H
#define MYSTRING_H

//#include "MyString.h"
//#include "Rover.h"
#include <iostream>

using std::ostream;

// struct String{
// 	char letter;
// 	int index;
// 	String *next;
// 	String *prev;
// };

class MyString {
	public:
		MyString();
		MyString(const MyString& str);
		MyString(const char* s);
		~MyString();	

		void resize(int n);
		unsigned int capacity() const;
		unsigned int size() const;
		int length() const;
		const char* data() const;
		bool empty()const;
		char front() const;
		char at(int pos)const;
		void clear();

		friend ostream& operator <<(ostream& os, const MyString& str);
		MyString& operator =(const MyString& str);
		MyString& operator +=(const MyString& str);
		//bool operator== (const MyString& lhs, const MyString& rhs);
		//MyString operator +(const MyString& lhs, const MyString& rhs);
		int find (const MyString& str,size_t pos=0) const;
	protected:
		//String *chars;
		int cap;
		int len;
		char* content;

};

#endif