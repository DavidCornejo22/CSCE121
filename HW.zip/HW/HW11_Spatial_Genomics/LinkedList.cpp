#include <iostream>
#include <string>
#include <sstream>
#include "LinkedList.h"
#include "Node.h"
#include <cmath>

using namespace std;
using std::string;
using std::ostream;

LinkedList::LinkedList():head(nullptr),tail(nullptr) {
	// Implement this function
    head = nullptr;
    tail = nullptr;
}

LinkedList::~LinkedList() {
    // Implement this function
    clear();
}

LinkedList::LinkedList(const LinkedList& source) 
{   // Implement this function
    if(&source!=this){
        Node *temp;
        Node *nextN;
        if(source.head==nullptr){ //if source head is empty
            this->head=nullptr;
            this->tail=head;
        }
        else{ //copy head
            this->head=new Node;
            this->head->data=source.head->data;
            temp=this->head;
            nextN=source.head->next;
            while(nextN!=nullptr){ //fill in
                temp->next=new Node;
                temp=temp->next;
                temp->data=nextN->data;
                nextN=nextN->next;
            }
            this->tail=temp;
            temp->next=nullptr;
        }
    }
}

LinkedList& LinkedList::operator=(const LinkedList& source) 
{   // Implement this function
    if(&source!=this){
        this->clear();
        Node *temp;
        Node *nextN;
        if(source.head==nullptr){ //if source head is empty
            this->head=nullptr;
            this->tail=head;
            return *this;
        }
        else { //copy head
            this->head=new Node;
            this->head->data=source.head->data;
            temp=this->head;
            nextN=source.head->next;
            while(nextN!=nullptr) { //fill in
                temp->next=new Node;
                temp=temp->next;
                temp->data=nextN->data;
                nextN=nextN->next;
            }
            this->tail=temp;
            temp->next=nullptr;
            return *this;
        }
    }
    return *this;
}

void LinkedList::insert(std::string id, int fov, double volume, double center_x, double center_y, double min_x, double max_x, double min_y, double max_y)
{   // Implement this function
    Node *temp = new Node(id, fov, volume,center_x,center_y,min_x,max_x,min_y,max_y);
    int count=0;
    if(head==nullptr){
        head=temp;
        tail=head;
    }
    else{
        Node *curr=head->next;
        Node *prev=head;
        if(temp->data<prev->data){ //if beginning
            temp->next=prev;
            head=temp;
            return;
        }
        while(curr!=nullptr){ //if middle
            if(temp->data<curr->data){ //checks fov
                prev->next=temp;
                temp->next=curr;
                return;
            }
            curr=curr->next;
            prev=prev->next;
        }
        prev->next=temp;
        tail=temp;
    }
}

void LinkedList::remove(std::string id, int fov, double volume, double center_x, double center_y, double min_x, double max_x, double min_y, double max_y)
{
    CellData data(id, fov, volume,center_x,center_y,min_x,max_x,min_y,max_y);
    int count=0;
    if(head==nullptr){
        head=nullptr;
        tail=nullptr;
    }
    else{
        Node *curr=head->next;
        Node *prev=head;
        if(data==prev->data){ //if beginning
            //temp->next=prev;
            Node *n = head->next;
            delete head;
            head=n;
            return;
        }
        while(curr!=nullptr){ 
           if(data==curr->data){ //if middle
                if(curr==tail){ //if end
                    prev->next=nullptr;
                    this->tail=prev;
                    delete curr;
                    return;
                }
                prev->next=curr->next;
                delete curr;
                return;
            }
            prev=prev->next;
            curr=curr->next;
        }
    }
}

void LinkedList::clear() 
{	// Implement this function
    Node *node=head;
    if(node==nullptr){
        this->head=nullptr;
        this->tail=nullptr;
        return;
    }
    Node *next=head->next;
    while(node!=nullptr){
        next=node->next;
        delete node;
        node=next;
    }
    this->head=nullptr;
    this->tail=nullptr;
}

Node* LinkedList::getHead() const {return head;}

string LinkedList::print() const 
{   // Implement this function
    Node *node=head;
    string intro="fov,volume,center_x,center_y,min_x,max_x,min_y,max_y\n";
    std::stringstream ss;
    ss<<intro;
    while(node!=nullptr){
        ss << node->data.id << ",";
        ss << node->data.fov << ",";
        ss << node->data.volume << ",";
        ss << node->data.center_x << ",";
        ss << node->data.center_y << ",";
        ss << node->data.min_x << ",";
        ss << node->data.max_x << ",";
        ss << node->data.min_y << ",";
        ss << node->data.max_y;
        ss<<endl;
        node=node->next;
    }
    cout<<ss.str();
    return ss.str();
    
}

//𝑣𝑜𝑙(𝑖) in the range of [𝑎𝑣𝑔𝑘()−𝑗*𝑑𝑒𝑙𝑡𝑎𝑘() , 𝑎𝑣𝑔𝑘()+𝑗*𝑑𝑒𝑙𝑡𝑎(𝑘)]
        //fov ==, left side less volume than OR right side greater than volume
        //delete
/* given a fov number, remove outliers */
string LinkedList::outliers(int k, int j, int N)
{   // Implement this function
    Node *node=head;
    
    int count=0;
    int d_k=sqrt(variance(k));
    double avg = average(k);
    double left=avg-j*d_k;
    double right=avg+j*d_k;
    while(node!=nullptr){
        if(node->data.fov==k){
            if(countN(node->data.fov)<N){
                return "Less than "+std::to_string(N)+" cells in fov "+std::to_string(k)+".";
            }
            if((node->data.volume<left)||(node->data.volume>right)){
                remove(node->data.id,node->data.fov,node->data.volume,
                node->data.center_x,node->data.center_y,
                node->data.min_x,node->data.max_x,node->data.min_y,node->data.max_y);
                count++;
            }
        }
        node=node->next;    
    }
    return std::to_string(count)+" cells are removed.";
}

/* given a fov number, compute the average volume of 
all the cells observed in that fov */
double LinkedList::average(int fov)
{   // Implement this function
    Node *node=head;
    int count=0;
    double sum=0.0;
    while(node!=nullptr){
        if(node->data.fov==fov){
            count+=1;
            sum=sum+(node->data.volume);
        }
        node=node->next;
    }
    if(count==0){
        return 0;
    }
    return sum/count;
}

//DO NOT CHANGE ANYTHING BELOW


ostream& operator<<(ostream& os, const LinkedList& ll) {
	/* Do not modify this function */
	os << ll.print();
	return os;
}

// given a fov number, count the cells observed in that fov
int LinkedList::countN(int fov)
{   /* Do not modify this function */
    int count = 0;
    Node* cur = head;
    while (cur)
    {
        if (cur->data.fov == fov)
            count++;
        cur = cur->next;
    }
    return count;
}

/* given a fov number, compute the variance 
volume of all the cells observed in that fov*/
double LinkedList::variance(int fov)
{   /* Do not modify this function */
    double sum = 0;
    double avg = average(fov);
    int count = countN(fov);

    if (count == 0)
        return -1;

    Node* cur = head;
    while (cur)
    {
        if (fov == cur->data.fov)
            sum += (cur->data.volume - avg) * (cur->data.volume - avg);
        cur = cur->next;
    }
    return sum/count;
}

