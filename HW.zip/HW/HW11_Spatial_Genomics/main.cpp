#include <iostream>
#include "CellDatabase.h"

using std::endl;
using std::cout;

int main(int argc, char** argv) 
{

// LinkedList ll;
// ll.insert("1",1250,1955.35,7492.66,3355.61,7484.17,7501.15,3343.78,3367.45);
// Node* node = ll.getHead();
// ll.insert("2",12,297.298,416.34,6078.29,412.765,419.915,6074.23,6082.35);
// node = ll.getHead();
// node=node->next; //tail
// ll.insert("3",13,425.921,404.352,5980.72,400.669,408.035,5975.09,5986.34);
// node = ll.getHead();
// node=node->next;
// node=node->next;
// ll.insert("4",1251,1295.67,7412.53,3086.69,7405.01,7420.04,3074.86,3098.53);
// node = ll.getHead();
// //ll.print();
// node=node->next;
// LinkedList ll2;
// ll2.insert("4",1251,1295.67,7412.53,3086.69,7405.01,7420.04,3074.86,3098.53);

// ll2 = ll;

// LinkedList ll3(ll);
// ll3.print();
// cout<<"\n\n\n";
// cout<<"ll2\n";
// ll2.print();
// ll2.clear();
// cout<<"ll2 after clear\n";
// ll2.print();
// cout<<"ll after clear\n";
// ll2=ll2;
// cout<<"ll2 printing itself\n";
// ll2.print();
// LinkedList ll4(ll2);
// cout<<"ll4 printing itself\n";
// ll4.print();
// ll.print();
// ll=ll;
// cout<<"ll after self copy\n";
// ll.print();
// return 0;
    if (argc < 3) 
    {
        cout << "Usage: " << argv[0] << " data_file query_file" << endl;
		    return 1;
    } 
    else 
    {
        CellDatabase database;
        database.loadData(argv[1]);
		database.performQuery(argv[2]); 
	  	database.outputData(argv[1]); 
    }

    return 0;
}
