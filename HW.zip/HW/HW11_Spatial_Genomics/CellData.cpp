/*CellData.h
 *
 *  Created on: Nov 9, 2021
 *      Author: student*/
#include <iostream>
#include <string>
#include "CellData.h"

using std::cout;
using std::string;

CellData::CellData(): id(""),fov(0),volume(0.0),center_x(0.0),
center_y(0.0),min_x(0.0),max_x(0.0),min_y(0.0),max_y(0.0) {} //initialize everything //done

CellData::CellData(std::string id, int fov, 
double volume, double center_x, double center_y,
double min_x, double max_x, double min_y, double max_y):
  id(id),fov(fov),volume(volume),center_x(center_x), center_y(center_y),
  min_x(min_x),max_x(max_x),min_y(min_y), max_y(max_y) {} //initialize everything

CellData::~CellData() {} // You should not need to implement this

//check fov && id atributes, if less than
bool CellData::operator<(const CellData& b) {
    if(this->fov<b.fov){
        return true;
    }
    else if(this->fov==b.fov){
        if(this->id<b.id){
            return true;
        }
    }
    return false;
	// Implement this
}

//check all atributes, if same
bool CellData::operator==(const CellData& b)
{   // Implement this
    return (id==b.id && fov==b.fov && volume==b.volume && center_x==b.center_x 
    && center_y==b.center_y && min_x==b.min_x && min_y==b.min_y && max_x==b.max_x && max_y==b.max_y);
    
}

