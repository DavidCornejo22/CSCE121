#include <iostream>
#include <string>
#include <sstream>
#include "CellDatabase.h"
#include "CellData.h"
#include <fstream>

using std::cout;
using std::string;
using std::fstream;
using std::ofstream;
using std::endl;

// Default constructor/destructor. Modify them if you need to.
CellDatabase::CellDatabase() {}
CellDatabase::~CellDatabase() {
    //this->next=CellData::clear();
};


void CellDatabase::loadData(const string& filename) 
{
    std::string id,test;
    int fov; double volume, center_x,center_y, min_x, max_x, min_y, max_y;
    bool leave=true;
    std::ifstream inputfile;
    inputfile.open(filename);
    string value,line;
    if(!inputfile.is_open()){
        cout<<"Error: Unable to open"<<endl;
        return;
    }
    getline(inputfile,line); //skip the first line
    // if(line!="id,fov,volume,center_x,center_y,min_x,max_x,min_y,max_y"){
    //     cout<<"Error, Invalid input: "<<line<<endl;
    // }
    while(!inputfile.eof()){
        getline(inputfile,line);
        if (line == "") break;
        std::stringstream ss(line);
        getline(ss,id,',');
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        leave=true;
        for(int i=0;i<id.size();i++){
            if(!isdigit(id.at(i))){
                cout<<"Error, Invalid input: "<<line<<endl;
                leave=false;
                //continue;
            }
        }
        if(leave==false) continue;
        ss>>fov;
        //stoi
        //try block, if error output string
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        //stod
        int comma = ss.get(); //consume the comma
        if(comma!=','){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }

        ss>>volume;
        if(ss.fail()||volume<0){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        // for(int i=0;i<volume.size();i++){
        //     //check to make sure HAS "."
        // }
        comma=ss.get(); //consume the comma
        if(comma!=','){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        ss>>center_x;
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        comma=ss.get(); //consume the comma
        if(comma!=','){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        ss>>center_y;
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        comma=ss.get(); //consume the comma
        if(comma!=','){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        ss>>min_x;
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        comma=ss.get(); //consume the comma
        if(comma!=','){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        ss>>max_x;
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        comma=ss.get(); //consume the comma
        if(comma!=','){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        ss>>min_y;
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        comma=ss.get(); //consume the comma
        if(comma!=','){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        ss>>max_y;
        if(ss.fail()){
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        comma=ss.get(); //consume the comma
        if(comma=='.'){                            //////CHECK
            cout<<"Error, Invalid input: "<<line<<endl;
            continue;
        }
        records.insert((string)id,(int)fov,(double)volume,(double)center_x,(double)center_y,
        (double)min_x,(double)max_x,(double)min_y,(double)max_y);
    }
    //bool isnan(double id);
    // Implement this function
    inputfile.close();
}

void CellDatabase::performQuery(const string& filename) 
{   // Implement this function
    int avg_k=0,count_k=0,out_k=0,out_j=0,out_n=0,avg_new=0;
    double var_k=0.0;
    string test="";
    const string output="result.data";
    std::ifstream inputfile;
    std::ofstream outputfile;
    inputfile.open(filename);
    outputfile.open(output);
    string value,line;
    if(!inputfile.is_open()){
        cout<<"Error: Unable to open"<<endl;
        return;
    }
    //outputfile<<"AVG 16: 1091.87\nVAR 16: 254541\nAVG 15: 962.332\nOUTLIER 20 3 20: 0 cells are removed.\nOUTLIER 20 2 20: 2 cells are removed.\nOUTLIER 20 1 20: 14 cells are removed.\nVAR 20: 33040.3"; 
    //return;
    while(!inputfile.eof()){
        getline(inputfile,line);
        if(line=="") break;
        std::stringstream ss(line);
        test="";
        ss>>test;
        if(test=="AVG"){
            ss>>avg_k;
            if(ss.fail()){                              //check
                outputfile<<"Error, Invalid input: "<<line<<"\n";
                continue;
            }
            outputfile<<test<<" "<<avg_k<<": "<<records.average(avg_k)<<"\n";
           
        }
        else if(test=="VAR"){
            ss>>var_k;
            if(ss.fail()){
                outputfile<<"Error, Invalid input: "<<line<<"\n";
                continue;
            }
             outputfile<<test<<" "<<var_k<<": "<<records.variance(var_k)<<"\n";
            
        }
        else if(test=="COUNT"){
            ss>>count_k;
            if(ss.fail()){
                outputfile<<"Error, Invalid input: "<<line<<"\n";
                continue;
            }
            outputfile<<test<<" "<<count_k<<": "<<records.countN(count_k)<<"\n";
           
        }
        else if(test=="OUTLIER"){
            ss>>out_k;
            if(ss.fail()){
                outputfile<<"Error, Invalid input: "<<line<<"\n";
                continue;
            }
            ss>>out_j;
            if(ss.fail()){
                outputfile<<"Error, Invalid input: "<<line<<"\n";
                continue;
            }
            ss>>out_n;
            if(ss.fail()){
                outputfile<<"Error, Invalid input: "<<line<<"\n";
                continue;
            }
             outputfile<<test<<" "<<out_k<<" "<<out_j<<" "<<out_n<<": "<<records.outliers(out_k,out_j,out_n)<<"\n";
            
        }
        else{
            outputfile<<"Error, Invalid input: "<<line<<"\n";
            continue;
        }
    
    }
    inputfile.close();
    outputfile.close();
}

// Do not modify
void CellDatabase::outputData(const string& filename) {
    ofstream dataout("sorted." + filename);
    if (!dataout.is_open()) {   
        cout << "Error: Unable to open " << filename << endl;
        exit(1);
    }
    dataout << records.print();
}


