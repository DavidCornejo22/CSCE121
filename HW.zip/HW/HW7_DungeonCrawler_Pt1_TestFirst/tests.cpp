#include <iostream>
#include "logic.h"

using namespace std;

// TODO(student): Write unit tests for the functions in logic.h
//       You should end up with at least 500 lines of test code

void Directions(int row,int col){
    char keyboard = 'q';
    row=0;col=0;
    for(int i=0;i<7;i++){
        getDirection(keyboard,row,col);
    }
    keyboard = 'e';
    for(int i=0;i<7;i++){
        getDirection(keyboard,row,col);
    }
    keyboard = 'w';
    for(int i=0;i<7;i++){
        getDirection(keyboard,row,col);
    }
    keyboard = 'a';
    for(int i=0;i<7;i++){
        getDirection(keyboard,row,col);
    }
    keyboard = 's';
    for(int i=0;i<7;i++){
        getDirection(keyboard,row,col);
    }
    keyboard = 'd';
    for(int i=0;i<7;i++){
        getDirection(keyboard,row,col);
    }
    
}

int main() {
    //loadLevel##########################################################
    int row,col;
    Player one;
    char **map=loadLevel("example.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            cout<<row_i<<"<-- row num || col num -->"<<col_i<<"  ";
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            cout<<row_i<<"<-- row num || col num -->"<<col_i<<"  ";
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("test2.txt",row,col,one);
    resizeMap(map,row,col);
    deleteMap(map,row);
    map=loadLevel("test2.txt",row,col,one);
    deleteMap(map,row);

    map=loadLevel("test6.txt",row,col,one);
    resizeMap(map,row,col);
    deleteMap(map,row);
    map=loadLevel("test6.txt",row,col,one);
    deleteMap(map,row);

    map=loadLevel("test7.txt",row,col,one);
    resizeMap(map,row,col);
    deleteMap(map,row);
    map=loadLevel("test7.txt",row,col,one);
    deleteMap(map,row);

    map=loadLevel("test8.txt",row,col,one);
    resizeMap(map,row,col);
    deleteMap(map,row);
    map=loadLevel("test8.txt",row,col,one);
    deleteMap(map,row);

    map=loadLevel("test9.txt",row,col,one);
    resizeMap(map,row,col);
    deleteMap(map,row);
    map=loadLevel("test9.txt",row,col,one);
    deleteMap(map,row);

    map=loadLevel("test3.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("test4.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("test10.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("test12.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("test13.txt",row,col,one);
    for(int row_i=0;row_i<row+2;row_i++){
        for(int col_i=0;col_i<col+2;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+2;row_i++){
        for(int col_i=0;col_i<col+2;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("test14.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("test15.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);

    row=0;col=0;
    map=loadLevel("easy1.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);
    row=0;col=0;
    map=loadLevel("easy2.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);
    row=0;col=0;
    map=loadLevel("hard1.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);
    row=0;col=0;
    map=loadLevel("hard2.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);
    row=0;col=0;
    map=loadLevel("hard3.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);
    row=0;col=0;
    map=loadLevel("tutorial4.txt",row,col,one);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    //extra?
    map=resizeMap(map,row,col);
    for(int row_i=0;row_i<row+1;row_i++){
        for(int col_i=0;col_i<col+1;col_i++){
            doPlayerMove(map,row,col,one,row_i,col_i);
            doMonsterAttack(map,row,col,one);
            Directions(row,col);
        }
    }
    deleteMap(map,row);


    //getDirection######################################################

    return 0;
}
